# Closest-prior full-text review

Review date: 2026-10-09. This is a comparison with selected primary sources,
not an exhaustive novelty certificate. No cited baseline was reproduced here.

## Driving on Memory

Source: [arXiv:2608.31029v1](https://arxiv.org/abs/2608.31029), a preprint.
Read all 23 PDF pages, including appendices. Visually checked Figure 2 and
Tables 2-6 against extracted text. The downloaded reference is read-only and
excluded from Git under `tmp/pdfs/`.

The paper replaces current cameras with pose-retrieved memories, while retaining
ego status. It reports NAVSIM v1/v2, Bench2Drive, RealEngine and HUGSIM results.
Importantly, it already includes HD-map-only inputs (Table 6), interaction groups
(Table 10), memory representation probes (Table 13), camera-memory fusion
(Table 14), and geographical controls (Table 7). Its short-horizon explanation
explicitly discusses pre-existing ego braking cues and conservative progress.
Appendix B.2 discloses different proposal-selection policies for some Bench2Drive
controls. These numbers are not a matched comparison with our small MLPs.

Our candidate distinction is **current-object alignment x encoder x data budget**
with a fixed ego/centerline context, separate lead summaries, controlled input
swaps, and paired session-cluster analysis. This paper does not establish that
our distinction is novel across all literature. Map strength, scenario breakdowns,
and adding NAVSIM v2 alone are insufficient novelty claims.

## PlanTF

Source: [Rethinking Imitation-based Planner for Autonomous Driving](https://arxiv.org/html/2309.10443v1).
Read the main text and supplementary result sections, including Tables I-VIII.

The study already relates input features to shortcut learning, uses a state
dropout encoder, tests augmentation/normalization, and separates trajectory
imitation from tracking dynamics. Its nuPlan protocol uses repeated closed-loop
planning, unlike our NAVSIM v1 scoring. Therefore “more inputs can hurt,” “an
encoder helps,” and open-/closed-loop disagreement are not standalone new ideas.
Our object-specific controls must distinguish an observed information effect
from extra dimensions, optimization, and input encoding. We do not reproduce
PlanTF or claim comparative superiority.

## Is Ego Status All You Need?

Source: [arXiv:2312.03031v2](https://arxiv.org/html/2312.03031v2).
Read its main text and appendices A-E in the primary HTML version.

The nuScenes study already tests camera corruption, ego-state perturbation,
map-task addition, straight/turn groups and convergence. It finds that input
effects can change with the evaluation metric and subgroup, and discusses
conservative plans. Appendix B aligns valid scene coverage and accounts for
yaw in collision checks; Appendix A identifies incorrect future labels in a
previous baseline. These are reasons to audit our extraction, not evidence
that the same bug exists here. Its inference-time corruptions are distinct from
our independently trained, cross-session donor controls. Raw sensor inputs,
nuScenes horizons and metric definitions differ from our privileged eight-object
NAVSIM experiment. Neither global perception redundancy nor safety equivalence
can follow from the comparison. Scenario effects alone are not a new contribution.

## PDM: centerline baseline and evaluation mismatch

Source: [Parting with Misconceptions about Learning-based Vehicle Motion Planning](https://arxiv.org/abs/2306.07962v2).
Read the 14-page primary PDF (main text pp. 1-8, followed by references);
visually checked p. 4, including Table 1. Also read all nine pages of the
[author-hosted supplement](https://danieldauner.github.io/assets/pdf/Dauner2023CORL_supplementary.pdf),
with a visual check of architecture/training and Table 4 on p. 6. It documents
separate nuPlan metric aggregation and training settings; our models do not copy
its history horizon, object forecasting or optimization schedule.

PDM-Open already conditions an MLP on an extracted centerline and ego history.
Table 1 separates centerline/history effects and open-/closed-loop performance;
Table 4 examines centerline resolution, length and model width. PDM-Closed also
uses object forecasting, proposals, controller simulation and scoring. Thus
centerline-only imitation is an established baseline, not a new architecture
here, and the paper cannot support removing environmental information from
general driving. Our four-second, one-query NAVSIM evaluation and present-state
eight-object branch are not a replication of its nuPlan evaluation. ADE reduction
cannot substitute for official PDMS evidence or deployment safety.

## NAVSIM: benchmark protocol and existing input/data ablations

Source: [NAVSIM: Data-Driven Non-Reactive Autonomous Vehicle Simulation and Benchmarking](https://arxiv.org/abs/2406.15349v2).
Read its main text pp. 1-10 in the 14-page primary PDF; visually checked Table 1
and Figure 4 on p. 7. Also read all 12 pages of the
[official NeurIPS supplement](https://proceedings.neurips.cc/paper_files/paper/2024/file/32768f7faf1995026ef9821c696f3404-Supplemental-Datasets_and_Benchmarks_Track.pdf),
with a visual check of the 15-combination PlanCNN/data-fraction design on p. 6.
Its v1.1 update collects DDC without adding it to PDMS; local default weights were
checked independently against that description.
The arXiv paper revision `v2` is not the NAVSIM benchmark-version-2 protocol.

Section 4.1 already evaluates PlanCNN input combinations with three training
fractions when studying metric alignment. Section 4.2 reports three TransFuser
seeds, input-range/state ablations and component metrics. Therefore an input
ladder, data curve, three seeds or a subscore plot alone is not a distinct
contribution. The paper's sensor-input comparisons cannot be ranked against our
privileged object/map models as if inputs and training were matched. Its
non-reactive, one-query protocol omits replanning feedback and compounded errors;
the discussion explicitly distinguishes high PDMS from closed-loop performance.
Our candidate distinction needs aligned-vs-donor object controls, encoder
interaction, same-city qualification and uncertainty with independent-session
sampling, not a restatement of those generic ablations.

## Deep Sets: established architecture, bounded theoretical claim

Source: [Deep Sets](https://arxiv.org/abs/1703.06114v3).
Read the main text pp. 1-8, theory/architecture appendices A-C (pp. 12-19),
and point-cloud architecture appendix H (pp. 26-27). Visually checked the
theorem qualifications on p. 2. Other application-specific appendices are not
part of this selected review.

Shared element transforms and commutative aggregation are established, including
conditioned and max-pooling variants. The sum-decomposition theorem has stated
domain/continuity/set-size qualifications; it is not a performance guarantee for
our finite-width masked mean/max encoder. M4/M5 are Deep-Sets-style baselines,
not a new set architecture or theorem. Reversal and padding tests establish
implementation invariance on tested inputs, not superior interaction reasoning,
sample efficiency or safety. Such empirical effects require the planned controls.

## Claim boundaries for this project

| Proposed claim | Evidence required here | Status |
|---|---|---|
| Current objects hurt this concatenation model | M1-M0, matched budget and paired seeds | Awaiting complete core scoring |
| Set encoding changes the object effect | M4-M1, convergence and parameter disclosures | Awaiting complete core scoring |
| The improvement uses scene-aligned information | M4-M5 and M1-M2; same-city auxiliary controls and exactly matched eligible coverage for a key alignment claim | Awaiting complete core scoring; base donors can also change city |
| Data budget changes the effect | Nested-session curves with fixed updates and epoch sensitivity | Gated follow-up |
| Effects differ across traffic situations | Frozen input-only strata, counts, metrics and uncertainty | Awaiting scoring |
| The same pattern holds under a new protocol | Separate v2 environment/caches and input-coordinate audit | Conditional extension |

If the controls do not separate these explanations, deliver the planned
reproducible technical report and state the inconclusive result. Do not retrofit
the manuscript around a favorable isolated seed or present Deep Sets as a new
architecture. This restriction preserves the original plan's stopping rule.
