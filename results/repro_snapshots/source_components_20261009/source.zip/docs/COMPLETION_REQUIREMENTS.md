# Full-scope completion requirements

This ledger derives from `PAPER_PLAN_2026-10-09.md`, its input-driven donor
qualification, and the active goal to finish the whole project. Code existence,
an active process, tests or a plausible draft do not prove experimental completion.
The goal must not be marked complete until every unconditional row and every
triggered conditional row is verified. A non-triggered/unsupported extension needs
its gate or actual feasibility evidence and an explicit manuscript disclosure.

| requirement | authoritative proof needed | current verification state |
|---|---|---|
| P0 model failures, fallback reasons and clipping | explicit diagnostics, numerical tests, real-scene ledger, stated historical measurement limits | implemented; legacy exhaustive fallback frequency is unknown and cannot be claimed zero |
| P0 blind execution does not need a map | fixture with inaccessible map/annotations and actual canonical input path | tested; old runtime copies preserved |
| P0 input geometry/velocity convention | upstream implementation, known-rotation tests and real track diagnostics | audited; absolute velocities in ego basis |
| P0 training-only normalization, masks and future exclusion | full archive/checkpoint audit, partition tests, history-only extraction | archive/core audits and 64 new live comparisons pass; sample limits disclosed |
| P0 historical artifacts preserved, units disclosed | untouched old checkpoint/score hashes, m/rad and privileged-path boundary | preserved/disclosed; final preservation audit still required |
| P1 frozen six conditions x three seeds | exact source/settings/donor/normalizer/checkpoint hashes and 13,000-update budget for all 18 | PASS: results/audit_v2/core_manifest.json; 18 full-budget runs, shared normalizer, max/min parameters 1.0773 |
| P1 live/cached new-model parity | official raw scenes with history-only adapter and paired outputs | PASS within sampled scope: mechanism_live.json, 16 scenes x four real-input seed-0 conditions; max 7.63e-6; no exhaustive/live-donor claim |
| P1 actual interrupted process recovery | baseline/resumed exact model, Adam, RNG, sampler and validation history | PASS: process_recovery.json, interrupted at 325/resumed to 1,000 smoke updates; exact equality; not scientific model evidence |
| P1 metric cache separation/recovery | independent new cache, two-scene smoke, complete raw token coverage and corruption/failure ledger | smoke and actual isolated three-fault recovery PASS (cache_recovery.json); first full-cache attempt stopped at critical RAM, receipts preserved; full validation/confirmation completion pending |
| P1 official scoring and provenance | score-path parity, full 18-model coverage on val/confirm/navtest, all subscores, zero final invalid scores and attempt-failure disclosure | old path parity passes; new full scoring pending |
| P1 matched-budget/parameter/latency/convergence evidence | artifact audit, actual parameter ratio, per-seed loss components and network-only timing table/figure | verified table in training_diagnostics/summary.json/.md; real convergence PNG and independently rasterized SVG visually accepted; vector_visual_qa.json and hash-bound librsvg receipt retained; training diagnostics only, not PDMS |
| P1 current-object order sensitivity | fixed same-scene permutation, per-model diagnostics; no retraining/counterfactual confusion | PASS for recorded first-512-validation reversal diagnostic; per-seed values audited; not all permutations/scenes |
| P2 frozen nested data fractions | 10/30/100% original-session subsets, unchanged validation and fitted subset-only normalization | protocol/tests pass |
| P2 fixed-update learning curves, if triggered | gate JSON, 12 additional full-budget M1/M4 models, aligned score archives and curve | gated training/evaluation/paired-analysis/source-rebuilt figure renderer implemented; first training attempt dependency-gated with zero jobs after evaluator memory stop; actual gate/models/scores/curve and scientific visual QA pending |
| P2 equal-epoch sensitivity, if triggered | 12 smaller-data epoch-budget runs; reuse full-data core; actual updates/epochs recorded | included in tested 24-job conditional matrix; actual execution/evaluation pending |
| P2 traffic strata and metric-progress figures | input-only masks, per-group scene/log/session counts, all seven metrics and uncertainty; inspected PNG/SVG | analysis/renderer implemented; scientific inputs/visual QA pending |
| P2 balanced diagnostic cases | immutable selection policy, outcome-bin counts/shortfalls, session restriction, all-seed plans, expert marked eval-only | selection tests pass; actual cases/visual QA pending |
| Five-seed follow-up for a seed-sensitive key claim | registered extension, paired seeds 3/4, same cohorts/budgets, guarded confirmation and full analysis; otherwise explicitly withhold claim | pending core evidence; cannot silently pick a seed |
| Same-city control for a key alignment claim | separate frozen inputs, same-city/cross-session invariants, exact common coverage, six auxiliary runs and anchor normalization parity; otherwise withhold claim | pre-outcome input audit PASS; prospective execution rule frozen at 08:39:33 UTC; six-model training, 36-export runner and strict independent 12-cell analysis implemented with fixture tests; train unchanged, val/confirm 10,312/8,379 with Singapore exclusions; actual auxiliary models/scores/reports/figures still pending |
| P3 cross-protocol, if triggered | gate, isolated pinned NAVSIM v2 checkout/environment, token/source overlap report, actual structured-input/synthetic-state smoke, separate cache, representative models/metrics | official source-grounded feasibility checklist present; no v2 execution yet; core-study v2 labels are not benchmark v2 |
| P3 resource feasibility | measured throughput/RAM/storage and explicit evidence of any unsupported dependency | low-memory sequential execution enforced; v2 feasibility pending |
| Closest prior and claim distinction | full selected-prior comparison and primary-source bibliography, no invented first/SOTA/acceptance claim | six selected papers checked, PDM/NAVSIM supplements and relevant Deep Sets appendices included; bibliography created; final citation audit pending |
| Evidence-grounded manuscript/report | final results populated from audited artifacts, inference/gating/history limitations, negative/inconclusive stopping rule | methods note only; final manuscript not written |
| Reproducibility package | frozen source/protocol/donor lineage, per-scene scores, exact commands/dependency/license notes, one-run smoke from documented instructions | runtime snapshot/guide present; no final package or end-to-end documented smoke yet |
| Final deliverables and verification | inspected scientific figures/cases, rendered manuscript PDF if provided, all required tests/commands/gates, this row-by-row audit with actual evidence paths | not complete |

The historical navtest motivated this study; it is exploratory. The new
confirmation is excluded from current-model training/normalization/selection, but
historical models saw it. Neither successful scoring nor low imitation loss
establishes deployment safety. Lack of a supported novel mechanism is an admissible
research result, but does not remove the obligation to finish the applicable
experiments, documentation, rendering and reproducibility checks.
