# Paper-plan execution record

This is a living execution record, not a completion or publication claim.
The original scope remains [the paper plan](PAPER_PLAN_2026-10-09.md).

## Verified deliverables

- P0 canonical agent: optional feature blocks; ego-only pose execution bypasses
  map/box work; explicit last-call and aggregate diagnostics; optional strict
  failure mode; endpoint-clipping indicator. Historical devkit copies, scores
  and checkpoints preserved.
- Full feature-archive audit: 103,288 navtrain / 12,146 navtest scenes, zero
  token/log/session overlap, finite inputs and targets, binary masks and zero
  raw padding. 27 archived models match training-only normalization exactly and
  produce finite cached-navtest outputs.
- Real-scene audit: 48 deterministic samples in 24 logs; features/targets and
  four live seed-0 agent outputs agree with cached computation. The fixture tests
  verify known rotations against upstream geometry, map independence and failure
  diagnostics. Sampling does not establish exhaustive historical fallback rates.
- Velocity convention: absolute object velocity expressed in the ego basis, not
  ego-relative velocity. 3,285 real track-pair finite-difference diagnostics have
  median error 0.131 m/s, p95 0.553 m/s; these are diagnostics, not exact identities.
- Official score-path parity: 128 agent/scene comparisons, maximum submetric
  error 4.96e-7.
- Both log- and original-session-cluster statistical reports. The no-map box
  effect is uncertain under session clustering.
- Frozen v2 protocol and deterministic cross-session donors. Train/val/confirm
  have 130/16/16 original sessions and 83,099/11,074/9,115 scenes. Thresholds and
  three primary contrasts were fixed before v2 outcome comparisons.
- Six model conditions implemented. All parameter counts are within 10%; masked
  Deep Sets handles empty sets and ignores padding. Current-input matching never
  uses future targets and never crosses partitions.
- Fixed-update training has atomic checkpoints, optimizer/sampler/RNG recovery,
  per-component validation losses and inference/order-sensitivity diagnostics.
  Smoke artifacts are explicitly ineligible for paper evaluation.
- Strict prediction export gates confirmation on all 18 verified core models.
  Scoring uses the original NAVSIM function/config, checks complete aligned token
  coverage, records failures and supports per-token SQLite recovery.
- Checkpoint recovery unit test restores model, Adam moments, sampler position
  and RNG and exactly reproduces the uninterrupted next update. The confirmation
  gate rejects an incomplete core manifest. All 7 agent-audit and 9 mechanism
  tests pass in the NAVSIM environment; repository code compiles successfully.
- A separately labelled 3-update Deep Sets smoke model was exported on navtest
  and scored on three tokens without exception. Its artifacts remain explicitly
  ineligible for paper results; no score from that smoke is a scientific finding.
- The complete 43-test suite passes in the NAVSIM environment with no skips.
- Closest-prior review now covers all 23 pages of Driving on Memory, including
  visual checks of its method and key result tables, and PlanTF's main text and
  supplementary result sections. The [comparison record](CLOSEST_PRIOR_REVIEW.md)
  narrows acceptable novelty claims without changing the experiment/stopping plan.
- The primary HTML main text and appendices A-E of Is Ego Status All You Need?
  have also been checked. Its metric/subgroup/input-corruption precedents further
  restrict what can count as a contribution.
- Twenty new analysis/case/gate/artifact-manifest tests pass. Case selection uses
  frozen positive/negative/neutral thresholds, token hashes and one case per
  original session per contrast; missing bins are reported, never filled by
  relaxing thresholds. All three seeds are displayed individually.
- The complete 63-test suite passes in the NAVSIM environment with no skips.
  Four additional donor/OS-lock tests separately pass, including cross-process
  exclusion and waiting until the current owner releases its lock. Historical
  report tests emit pre-existing unclosed-file warnings but no test failures.
- After the new input/runner checks and provenance tightening, the complete
  67-test suite also passes in the NAVSIM environment with no skips (214.9 s).
  Prediction receipt verification confirms unchanged complete validation coverage.
- Numeric follow-up gates are now separately frozen. They were added after core
  training began but before full controlled score comparisons; this timing is
  explicit. Negative effects can trigger data-budget curves, not only improvements.
- Input-only donor diagnostics pass partition/session independence. Same-city
  donor rates are 42.4% train, 43.7% validation, 37.1% confirmation and 29.6% navtest.
  The controls can change city distribution as well as scene alignment. They
  cannot isolate dynamic interaction use; a key alignment claim requires a
  separately frozen same-city control or must be withheld. The complete raw
  cohort audit now passes: all 103,288/12,146 selected training/test tokens have
  feature records, with zero missing logs or selected scenes without features.
  This coverage audit does not reconstruct historical fallback reasons.
- The full M0 seed-0 checkpoint exports all 11,074 validation predictions with
  finite outputs and complete provenance. Repeating the export verifies and
  reuses its hash-bound receipt without changing the prediction archive.
  This is inference/export validation, not a PDMS score or completed core result.
  Confirmation export remains gated on every core model.
- The same-city donor generator and separate extension design are implemented.
  Four tests pass for strict city/session constraints, deterministic matching,
  explicit unsupported-city exclusion and current-input-only access. Actual
  auxiliary input freezing/training/evaluation still requires its memory/gate checks.
- The standalone core-figure renderer is implemented with production provenance
  gates and clearly ineligible synthetic layout smoke mode. Scientific rendering
  and visual inspection have not yet happened; source existence is not a figure result.
- Upstream enum inspection confirms generic_object is not an AGENT_TYPE. The
  unchanged selected-object branch contains vehicle/pedestrian/bicycle/generic
  categories; bicycle/generic objects share zero type flags. Methods and scope
  statements now disclose this instead of implying exclusively moving actors.
- A [full-scope requirements ledger](COMPLETION_REQUIREMENTS.md) and
  [methods note](CONTROLLED_METHODS.md) separate verified design from pending
  experiments, rendering and the eventual evidence-grounded manuscript.
- All 18 full-budget core models have completed and pass the actual
  `results/audit_v2/core_manifest.json` check: 13,000 updates each, one shared
  full-data normalizer, and parameter max/min 1.0773. The verified
  `training_diagnostics/summary.json` and `.md` retain per-seed losses, timing,
  order sensitivity and history/checkpoint hashes. These are not PDMS findings.
- Actual process interruption/recovery passes at 1,000 smoke updates after
  interruption at 325: exact model/Adam/RNG/sampler/validation history equality.
  New-model live/cached parity passes on 16 deterministic scenes x four real-input
  seed-0 conditions (64 comparisons, max pose error 7.63e-6). The scope is sampled,
  not every scene/seed or a live physical interpretation of donor controls.
- The new two-token validation cache smoke passes. Full validation caching was
  interrupted for critical memory pressure; confirmation caching and complete controlled scoring are not complete.
  No new PDMS comparison exists at this record update.
- The registered 24-job smaller-data training runner is implemented. Its first
  attempt (session 20056) exited without training when the required validation
  analysis report was absent after the evaluator stopped. It verifies the gate against actual hash-bound validation
  score CSVs, uses 12 fixed-update and 12 equal-epoch jobs only if triggered, and
  does not produce driving-score curves by completing training alone.
- Same-city design/source hashes were bound before any complete core comparison
  report existed (`city_protocol/design.json`, 2026-10-09T06:57:46Z). Actual donor
  generation has not run: its 2,200-MB free-memory guard correctly refused a
  low-memory attempt. Do not change the bound generator silently.
- The renderer's synthetic layout smoke ran and was inspected. Footer overlap
  and empty-row clipping were found and fixed in source; rerender/inspection of
  the corrected outputs and real scientific figures remain pending safe memory.
- Six selected primary papers are covered by the closest-prior record, including
  PDM/NAVSIM official supplements and selected Deep Sets theory/architecture
  appendices. The six-entry bibliography contains no invented publication claim.
  PDM centerline baselines and NAVSIM input/data ablations further constrain novelty.
- The new city-design/curve-gate/training-summary/plot-fixture tests pass separately;
  the last full suite was 67 tests before these 17 additions. An updated complete
  suite and final scientific/reproducibility audit have not yet run.
- A current [reproducibility guide](REPRODUCIBILITY.md) and runtime snapshot record
  the real CPU environment, 201 installed dependency versions, 160 tracked
  upstream hashes and the preserved local dataloader patch. The snapshot is
  current evidence, not a retrospective pre-launch source immutability claim.
- The critical-memory attempt is now preserved separately. Nine resource-guard
  tests pass, including actual owned-child termination while an unrelated child
  remains live. The complete 93-test suite passed in 174.841 seconds with no
  skips before the subsequent curve/city/cache-recovery test additions.
- Corrected synthetic layouts were rerendered into a separate folder and all
  three PNGs visually inspected; they remain scientifically ineligible. The
  real 18-model convergence PNG was also inspected with its receipt/history/model
  hashes bound in `figures/training/visual_qa.json`. Independent SVG rasterization
  remains uninspected; no real PDMS figure exists yet.
- Actual same-city donors are now frozen and independently audited in
  `results/audit_v2/city_inputs.json`. Training stays 83,099 scenes/130 sessions;
  validation is 10,312 scenes/15 sessions (762 Singapore scenes excluded),
  confirmation 8,379/15 (736 excluded), and navtest 12,146/44 without exclusions.
  All eligible mappings have same-city and different-session fractions of 1.0.
  The inherited base diagnostic limitation string is explicitly qualified by the
  separate audit; frozen sources/receipts were not rewritten. No auxiliary model
  has been trained or scored.
- Actual isolated cache recovery passes three deliberate faults (empty file,
  truncated LZMA and invalid pickle) in a newly created two-scene test directory.
  Each restored file is byte-identical to its baseline, has identical checked
  semantics and zero official-submetric error for the fixed anchor trajectory;
  the untouched second file remains unchanged. Formal/historical cache roots were
  not targets of mutation. This is a recovery audit, not full cache coverage or a
  scientific performance finding (`results/audit_v2/cache_recovery.json`).
- Guarded curve evaluation and paired analysis are implemented separately from
  the base core analyzer. They require all 24 follow-ups plus six reused anchors,
  aligned score coverage, subset normalizers and the verified actual-score gate
  before auxiliary confirmation. Fixed-update/equal-epoch curves share the same
  full-data anchor; four small-minus-full encoder-effect sensitivity contrasts
  are paired by scene/session. Execution and real curve figures remain pending.
- The [benchmark-v2 feasibility checklist](CROSS_PROTOCOL_FEASIBILITY.md) is
  grounded in the official version/metric/install documents. It separates v1 PDMS,
  v2 one-stage EPDMS and two-stage aggregation and requires exact commit/fix,
  data-overlap, synthetic-state and measured-resource checks. None has run yet.
- The complete 105-test suite passed in 143.521 seconds, with a retained command,
  guard and output log under `run_attempts/2026-10-09_full_suite_105.*`. Two upstream
  baseline-binding and two cache-resumption tests subsequently passed separately;
  the updated 109-test suite has not run as one complete invocation. Repository
  sources compile and `git diff --check` passes (line-ending warnings only).
- All 160 tracked devkit files still match the preserved current-runtime snapshot.
  The new controllers bind upstream files/configuration, including the legitimate
  existing dataloader patch, and refuse changes before later stages. This is a
  current-baseline check, not proof of historical/pre-training source immutability.

## Active execution

The 18-model core training runner has been launched with two CPU threads per
child, serial jobs, below-normal child priority and a free-memory guard.
Authoritative progress is the live process/tool session plus checkpoint hashes;
`results/mechanism_v2/core_status.json` alone is only a progress record, not proof
that a process is alive. Logs/checkpoints are under
`E:/navsim_workspace/exp/mechanism_v2`.

Core training is finished (18/18); the runner exited successfully and all
artifacts were independently verified. This is a training milestone, not a new
PDMS claim. Later evaluation state is available in the evaluator's log/manifest.

The initial serial evaluation attempt (session 71587, PID 26060) exited with
code 1 after deliberate termination of its owned cache child at critical RAM
pressure (392/284/346 MB free). No unrelated job was stopped. The curve runner
then exited through its missing-validation-report dependency gate, with zero
training jobs. Their terminal manifests are preserved under
`results/mechanism_v2/run_attempts/2026-10-09_memory_stop/`, together with an event
ledger. At the later inventory there were 1,489 partial new-cache files (592.1 MB);
file presence does not prove valid complete coverage. No material file was deleted.

The evaluation supervisor now requires 2,400 MB continuously for 20 seconds before
launch and monitors the owned child every five seconds. It stops that child tree
at one observation below 512 MB or two consecutive observations below 1,000 MB.
Only the resumable full validation/confirmation cache stages can automatically
wait and retry after a recorded memory interruption; other stages or ordinary
nonzero exits require explicit review. Every retry retains its attempt/failure
record and validates existing cache files. Scientific model/scoring sources and
the frozen protocol remain unchanged. Testing and a new live launch must be
verified separately; a status JSON alone is never proof of liveness.

Artifact/input audits, actual process recovery, live parity and cache smoke have
passed. Full scoring remains pending. A completed evaluator would cover core
evaluation only, not the complete paper-plan goal.

The guarded retry (session 44637, runner PID 40308) has also exited with code 1:
repeating `input_controls` reached 500.33 MB free and the watchdog stopped only
the owned child tree. The terminal attempt is preserved under
`run_attempts/2026-10-09_watchdog_stop/`. The second queued curve attempt (session
14889, PID 40316) then correctly exited through the absent-validation-report
dependency gate, again with zero training jobs. Neither process remains live.

The earlier completed full input/recovery/live/cache-smoke audits remain present
and pass; their source/protocol hashes have not changed. Cache work is now isolated
in `resume_mechanism_cache.py`, which checks that original successful attempt,
re-verifies all 18 models, binds the actual audit receipts and upstream baseline,
and explicitly does not rerun or retrospectively relabel those completed audits.
It builds only validation/confirmation caches, preserving attempt failures and
retrying only recorded memory interruptions. Scoring remains separate and gated.

At the earlier 2026-10-09T07:50:04Z observation the cache-only controller was live (actual PID 41048,
launcher PID 40736, session 60359), **waiting for memory with no cache child**.
Measured free RAM was 1,642 MB, below its continuous 2,400-MB launch condition.
Its authoritative attempt receipt is
`run_attempts/cache_resume_20261009T074804Z_41048.json`; `cache_resume_status.json`
is only a progress snapshot. No new full PDMS score or active curve training was
claimed. Do not rerun bound audits/modify frozen files while a live controller owns
the heavy-job lock; review source/receipt changes explicitly instead.

The donor city/session audit also identifies an important extension constraint:
Singapore has only one original session in each validation/confirmation partition.
A strict same-city cross-session control cannot evaluate those partitions there;
that coverage loss must be explicit. All training cities have at least 12 sessions,
so a same-city training donor pool is feasible without removing a training city.

## Later memory-safety stop and conditional city implementation

The cache controller actually started validation. Attempt 1 stopped at two
observations of 838.73/900.21 MB. Attempt 2 launched with 3,152.84 MB and reached
5.36 MB free, triggering its emergency stop. Attempt 3 subsequently launched;
because this automatic retry pattern risks another system freeze, its verified
owned launcher tree (40736, actual runner 41048) and the queued scorer tree
(42412, actual runner 39092) were explicitly stopped. Both tool sessions ended
with exit 1. No cache/model file or unrelated process was removed. The unfinished
third cache child's terminal code was not independently measured.

Terminal external-stop annotations and the two raw pre-stop snapshots are retained
under `run_attempts/2026-10-09_cache_headroom_stop/`; the old cache supervisor source
is preserved there with its original SHA256
`3d67cd2287fdd78158961f625bec7bb9810091a97ddee32e299b3a2c71ad35b6`.
The progress snapshots alone are not evidence these terminated runners remain live.

The cache-only supervisor now requires 6,000 MB continuously for 30 seconds,
checks its owned child every 0.5 seconds, stops it at an observation below
2,000 MB (emergency below 1,500 MB), and **does not automatically retry a memory
interruption**. This is an operational policy change after actual pressure, not
a scientific protocol/model/scorer change. It cannot guarantee immunity to
unrelated allocations. Its dedicated policy/error tests passed; any new launch
must use a new attempt receipt and independently verify liveness.

The independent scoring controller's six fixture tests passed. It requires both
full cache receipts, reuses source-bound completed audits without repeating the
high-memory raw input audit, and schedules exactly 54 core exports. Its first
queued attempt started zero child scoring jobs before the external stop.

The same-city execution rule was frozen at 2026-10-09T08:39:33Z before complete
core comparison reports: absolute validation M1-M2 or M4-M5 >=0.01 triggers all
six auxiliary models. Both signs may trigger; no trigger withholds the clean
alignment interpretation. This extends the execution policy rather than
pretending the numeric rule was in the original text. Actual decisions recompute
the effects from all 18 core CSVs and check source/model/protocol hashes.

Separate city training/export/evaluation/analysis sources are implemented. The
confirmation entry requires all 18 base and six auxiliary full-budget artifacts;
the 12 fitted cells use identical eligible tokens/logs, and real-anchor predictions
must equal the corresponding full-archive subset. Three session-paired auxiliary
contrasts include the alignment-by-encoder difference of differences, conditional
on three fitted seeds. Auxiliary-family intervals do not establish unconditional
global confirmatory coverage. The 25 newly added city fixture tests separately
passed; the combined city-pattern suite then passed all 34 tests in 2.000 seconds,
with its command, guarded exit-0 receipt and complete log retained at
`run_attempts/2026-10-09_city_fixture_suite.{json,log}`. Scientific city models/scores, figure QA and the updated full suite remain
pending. Actual read-only checks still verified 18 core models, city validation
10,312 scenes, and the original 15 source/policy bindings; bound audit files were
not overwritten.

After the safety-policy tests, a new cache-only attempt was launched:
`run_attempts/cache_resume_20261009T085623Z_30252.json`, session 94130,
actual runner PID 30252 (launcher 40608). The new scorer is queued in
`run_attempts/core_scoring_20261009T085658Z_37152.json`, session 27613,
actual PID 37152 (launcher 36956). Both were independently found in the OS
process inventory. The observed cache state is **waiting_for_memory, no child**;
the scorer is waiting for its lock with no child. The initial free-RAM reading
was 3,720.75 MB, below the new 6,000-MB launch condition. These live waiting
controllers are not complete caching/scoring evidence. The cache supervisor's
four tests, including the effective first-low-sample 2,000-MB stop, passed;
compileall and git diff --check passed. The updated full suite still has not run.

## Follow-up rendering and separate component checks

The actual full-budget training SVG was independently rasterized with
sharp/libvips/librsvg and its entire raster was visually inspected: four panels,
metre/radian units, legends and min/max-seed scope are readable. The unchanged
scientific SVG/receipt and the independently generated raster are hash-bound in
`figures/training/vector_visual_qa.json`. This closes vector layout QA for training
diagnostics only; it supplies no PDMS or deployment-safety evidence.

The city/curve analyzers now expose reusable source-rebuilding functions. City
analysis requires its actual execution gate before loading features; curve
analysis checks the current scoring configuration and an explicit workspace.
`plot_followups.py` rebuilds the report from model/score/prediction provenance
before rendering, rather than trusting an edited summary JSON. It adds seven
city/curve contrast, stratum, submetric and budget figures. Both pending evaluation
runners include this rendering stage, but rendering is not visual acceptance.

Separate observed tests passed: plot helpers 8, builder gate-order fixtures 2,
curve analysis 7, city analysis 5, and the installed SVG rasterizer's Node tests 4
with zero skips. Their scoped summary is
`run_attempts/2026-10-09_followup_component_tests.json`; stdout is available in the
tool outputs, not an independently retained complete log. These are not a rerun
of the full suite or evidence that auxiliary experiments have completed.

All seven first-pass synthetic layout PNGs were inspected and were readable.
Review found that the fixture did not exercise wider multiplicity-adjusted
intervals, and small negative heatmap values displayed as "-0.000". The original
renderer is preserved as `run_attempts/2026-10-09_first_followup_layout_renderer.py`.
The fixture interval width and rounded label presentation were corrected without
changing scientific interval calculations; two additional tests pass. Corrected
layout generation completed in session 53169 (exit 0) under the resource guard,
in the two `tmp/followup_layout_smoke_*_20261009_v2` directories. All seven corrected
PNG outputs were then inspected, including a separate original-detail view of
the encoder curve. Wider adjusted intervals and rounded zero labels are visibly
correct; titles/captions, empty/single-session strata and reused full-data anchors
are readable. The source, render receipts and inspected PNG hashes are bound in
`run_attempts/2026-10-09_followup_layout_png_qa.json`. All fixtures remain
scientifically ineligible. Independent fixture SVG rasterization then completed
in guarded session 67570 (exit 0). All seven independent SVG rasters were actually
viewed, including the complete encoder curve separately, and their source,
fixture-receipt, independent-receipt and raster hashes rechecked. Titles, captions,
ordinary/adjusted intervals and heatmap labels are readable. This separate
acceptance is bound in `run_attempts/2026-10-09_followup_layout_vector_qa.json`;
it closes synthetic fixture PNG/SVG layout QA, not scientific figure requirements.
The eight plot helper tests were rerun and passed in 0.004 seconds, and the seven
corrected PNG hash bindings also passed an actual post-inspection audit.

The user elected to wait for other tasks to release RAM. The cache/scoring
controllers remain live waiting, with no child reported; no unrelated task was
stopped and the 6,000-MB-for-30-seconds cache launch condition is unchanged.
Brief RAM windows allowed small component/fixture work, not full caching. This
waiting state is not evidence of experimental completion.

## Required remaining work

1. Keep the verified 18-model core artifacts and sampled live parity/recovery
   evidence intact; perform final preservation/provenance checks after experiments.
2. Finish complete validation/confirmation caching and separately exercise cache
   corruption/recovery; preserve historical caches and disclose failures.
3. Score validation, frozen confirmation and exploratory navtest; audit token
   coverage, exceptions, provenance and all submetrics.
4. Produce paired per-seed effects, session-cluster intervals, multiplicity-aware
   primary comparisons, scenario effects and parameter/latency/convergence tables.
5. Apply the planned mechanism gate. Where informative, run the 12 additional
   fixed-step learning-curve models and equal-epoch sensitivity; do not silently
   promote smoke models or skip a failed experiment.
6. Generate the scientific figures and deterministically selected failure cases.
7. Review closest related work in full; conditionally execute the v2 cross-protocol
   extension after the core evidence/feasibility gate, with separate environment
   and caches. Do not relabel it full closed-loop safety validation.
8. Write the evidence-grounded manuscript and reproducibility package, then audit
   every paper-plan requirement. No acceptance or unmeasured benefit is promised.

## Reproduction commands

Run from the repository with the NAVSIM virtual environment and workspace env:

```powershell
. E:\navsim_workspace\env.ps1
& $env:NAVSIM_PYTHON analysis\audit_features.py --threads 2
& $env:NAVSIM_PYTHON analysis\validate_score_path.py --scenes 32
& $env:NAVSIM_PYTHON analysis\prepare_mechanism.py
& $env:NAVSIM_PYTHON analysis\run_mechanism_core.py --threads 2
```

Do not launch a second core runner: its OS-level lock prevents duplicate work.
Do not launch cache construction concurrently with full training on this 16 GB
machine. After core training, use `cache_mechanism.py --split validation`, then
`--split confirmation`; both share the new versioned cache and preserve the
historical navtest cache. Prediction/score tools have explicit run/output paths.

For the reviewed isolated cache/score route after sufficient resources, use:

```powershell
& $env:NAVSIM_PYTHON analysis\resume_mechanism_cache.py
# Only after both complete cache receipts; --wait-for-cache can queue on the lock.
& $env:NAVSIM_PYTHON analysis\run_mechanism_scoring.py --wait-for-cache
```

Do not launch a second evaluator; its cross-process lock prevents duplicates.
The scorer waits on the core lock, verifies actual cache/core completion and checks
source/policy hashes before each child stage. State JSON alone is not liveness.
Do not resume the old monolithic raw-audit route as a workaround for low RAM.
City training/evaluation commands are separate and fail closed before their
actual-score gate and prerequisite completion; they have not been launched.
